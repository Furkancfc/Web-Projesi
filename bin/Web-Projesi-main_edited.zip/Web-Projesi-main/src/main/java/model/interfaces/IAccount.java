package model.interfaces;

public interface IAccount extends IGeneric<model.Account> {
	
}
