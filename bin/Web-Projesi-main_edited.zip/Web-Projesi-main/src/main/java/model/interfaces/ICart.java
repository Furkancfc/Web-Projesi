package model.interfaces;

public interface ICart extends IGeneric<model.Cart> {
	 
}
