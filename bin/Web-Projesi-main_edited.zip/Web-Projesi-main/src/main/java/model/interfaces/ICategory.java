package model.interfaces;

public interface ICategory extends IGeneric<model.Category> {
}
