package model.interfaces;

public interface IItem extends IGeneric<model.Item>{

}
