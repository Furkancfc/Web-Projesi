package service.interfaces;

public abstract class CategoryService extends Service{
	public abstract void addCategory(model.Category category);
}