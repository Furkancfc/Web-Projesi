package service.interfaces;
public abstract class ItemService extends Service{
	
}