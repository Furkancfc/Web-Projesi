package service.interfaces;

public abstract class Service {

}