package service.interfaces;

public abstract class UserService extends Service {

}